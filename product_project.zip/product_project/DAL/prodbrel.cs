using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace firstproject.DAL
{
    public class prodbrel:DbContext 
    {
        public prodbrel(DbContextOptions options): base(options)
        {

        }
        public DbSet<products> Products{get;set; }
    }
}