﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using firstproject.Models;
using Microsoft.AspNetCore.Http.Features;


namespace firstproject.Controllers;

public class HomeController : Controller
{
    
   

    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        List<User> ListUsers=new List<User>();
        //User obj=new User();

        User obj1=new User();
        obj1.id=1;
        obj1.Name="hamid";
        obj1.Family="ixian";
        obj1.Age=40;
        obj1.City="tehran";
        obj1.Gender=true;
        ListUsers.Add(obj1);

        User obj2=new User();
        obj2.id=2;
        obj2.Name="ali";
        obj2.Family="felani";
        obj2.Age=40;
        obj2.Gender=false;
        obj2.City="fars";
        ListUsers.Add(obj2);
        
        User obj3=new User();
        obj3.id=3;
        obj3.Name="navid";
        obj3.Family="bahmani";
        obj3.Age=40;
        obj3.Gender=true;
        obj3.City="fars"; 
        ListUsers.Add(obj3);
        
        User obj4=new User();
        obj4.id=4;
        obj4.Name="John";
        obj4.Family="Stone";
        obj4.Age=40;
        
        obj4.City="fars"; 
        ListUsers.Add(obj4);

        User obj5=new User();
        obj5.id=5;
        obj5.Name="Ponnappa";
        obj5.Family="Priya";
        obj5.Age=45;
        obj5.Gender=false;
        obj5.City="new york"; 
        ListUsers.Add(obj5);


        var query=ListUsers.Where(x=>x.Age==40).ToList();
      
        
        
        //sample of HasValue
        // int SumAge=0;
        // foreach(var a in query)
        // {
        //     if(a.Gender.HasValue)
        //     {
        //     SumAge +=a.Age;
        //     }
        // }
      
      
      
       // var query=ListUsers.Where(x=>x.City=="fars").Count();
       // User obja=new User();


        return View(query);
//36
         
    }

    public IActionResult Privacy()
    {
        return View();
    }
    public IActionResult About()
    {
       
        int a=15;
        string city="newjercy";
        string he=$"hello I am {a} years old and i live in {city}";
        ViewBag.RES=Func_1();
        ViewBag.THISSHOW=he;
        return View();
    }
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
    string Func_1(){
    int a=12;
    int b=13;
    return (a*b).ToString();
}
}
