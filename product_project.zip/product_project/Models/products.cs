using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;

public class products{
    
      
       public string name{get;set;}//required
       
       public int? price{get;set;}
       public int offer{get;set;}

       public string image{get;set;}
       public string? image_path{get;set;}

}