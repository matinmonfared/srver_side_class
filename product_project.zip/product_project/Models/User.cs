// using System;
// using System.Collections.Generic;
// using System.ComponentModel.DataAnnotations;
// using System.Linq;
// using System.Threading.Tasks;
// using Microsoft.AspNetCore.SignalR;

// namespace firstproject.Models
// {
//     public class User
//     {
//        [Required]
//        [Key]
//        public int id{get;set;}//required
//        [StringLength(100)]
//        [Required]
//        public string Name{get;set;}//required
//        [StringLength(100)]
//        public string? Family{get;set;}
//        [StringLength(50)]
//        public string? City{get;set;}
//        public int Age{get;set;}
//        public bool? Gender{get;set;}

//     }
// }